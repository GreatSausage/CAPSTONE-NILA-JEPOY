-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2025 at 11:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbmcpms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartment`
--

CREATE TABLE `tbldepartment` (
  `departmentID` int(11) NOT NULL,
  `departmentName` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbldepartment`
--

INSERT INTO `tbldepartment` (`departmentID`, `departmentName`, `status`) VALUES
(1, 'First Department', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployee`
--

CREATE TABLE `tblemployee` (
  `employeeID` int(11) NOT NULL,
  `employeeNumber` varchar(255) NOT NULL,
  `rfidNumber` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `departmentID` int(11) NOT NULL,
  `positionID` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `logged` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblholiday`
--

CREATE TABLE `tblholiday` (
  `holidayID` int(11) NOT NULL,
  `date` date NOT NULL,
  `classification` varchar(255) NOT NULL,
  `holidayName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblholiday`
--

INSERT INTO `tblholiday` (`holidayID`, `date`, `classification`, `holidayName`) VALUES
(1, '2024-11-02', 'First Classification', 'First Holiday'),
(2, '2024-11-13', 'asda', 'asdad');

-- --------------------------------------------------------

--
-- Table structure for table `tblincentives`
--

CREATE TABLE `tblincentives` (
  `incentiveID` int(11) NOT NULL,
  `incentiveName` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblincentives`
--

INSERT INTO `tblincentives` (`incentiveID`, `incentiveName`, `status`) VALUES
(1, 'First Incentive', 'Active'),
(2, 'Second Incentive', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tblleave`
--

CREATE TABLE `tblleave` (
  `leaveID` int(11) NOT NULL,
  `leaveType` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblleave`
--

INSERT INTO `tblleave` (`leaveID`, `leaveType`, `status`) VALUES
(1, 'First Leave', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tblpagibig`
--

CREATE TABLE `tblpagibig` (
  `pagibigID` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpagibig`
--

INSERT INTO `tblpagibig` (`pagibigID`, `rate`, `date`) VALUES
(1, 12, '2025-02-23 16:00:22');

-- --------------------------------------------------------

--
-- Table structure for table `tblphilhealth`
--

CREATE TABLE `tblphilhealth` (
  `philhealthID` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblphilhealth`
--

INSERT INTO `tblphilhealth` (`philhealthID`, `rate`, `date`) VALUES
(1, 12, '2025-02-23');

-- --------------------------------------------------------

--
-- Table structure for table `tblposition`
--

CREATE TABLE `tblposition` (
  `positionID` int(11) NOT NULL,
  `positionName` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'Active',
  `departmentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblposition`
--

INSERT INTO `tblposition` (`positionID`, `positionName`, `status`, `departmentID`) VALUES
(1, 'Department Head', 'Active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblrates`
--

CREATE TABLE `tblrates` (
  `rateID` int(11) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `rateClassification` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblrates`
--

INSERT INTO `tblrates` (`rateID`, `rate`, `rateClassification`) VALUES
(1, '110', 'Night Differential'),
(2, '125', 'Overtime-Regular'),
(3, '130', 'Overtime-Special'),
(4, '135', 'Rest Day'),
(5, '130', 'Special Holiday'),
(6, '200', 'Regular Holiday'),
(7, '260', 'Double Holiday');

-- --------------------------------------------------------

--
-- Table structure for table `tblsss`
--

CREATE TABLE `tblsss` (
  `sssID` int(11) NOT NULL,
  `minSalary` decimal(10,2) NOT NULL,
  `maxSalary` decimal(10,2) NOT NULL,
  `ee` decimal(10,2) NOT NULL,
  `er` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbltaxdaily`
--

CREATE TABLE `tbltaxdaily` (
  `taxID` int(11) NOT NULL,
  `minSalary` decimal(10,2) NOT NULL,
  `maxSalary` decimal(10,2) NOT NULL,
  `fixedAmount` decimal(10,2) NOT NULL,
  `percentage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbltaxmonthly`
--

CREATE TABLE `tbltaxmonthly` (
  `taxID` int(11) NOT NULL,
  `minSalary` decimal(10,2) NOT NULL,
  `maxSalary` decimal(10,2) NOT NULL,
  `fixedAmount` decimal(10,2) NOT NULL,
  `percentage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblvoluntary`
--

CREATE TABLE `tblvoluntary` (
  `voluntaryID` int(11) NOT NULL,
  `voluntaryName` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblvoluntary`
--

INSERT INTO `tblvoluntary` (`voluntaryID`, `voluntaryName`, `status`) VALUES
(1, 'First Voluntaryyy', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  ADD PRIMARY KEY (`departmentID`),
  ADD UNIQUE KEY `departmentName` (`departmentName`);

--
-- Indexes for table `tblemployee`
--
ALTER TABLE `tblemployee`
  ADD PRIMARY KEY (`employeeID`),
  ADD UNIQUE KEY `employeeNumber` (`employeeNumber`),
  ADD UNIQUE KEY `rfidNumber` (`rfidNumber`);

--
-- Indexes for table `tblholiday`
--
ALTER TABLE `tblholiday`
  ADD PRIMARY KEY (`holidayID`),
  ADD UNIQUE KEY `holidayName` (`holidayName`);

--
-- Indexes for table `tblincentives`
--
ALTER TABLE `tblincentives`
  ADD PRIMARY KEY (`incentiveID`);

--
-- Indexes for table `tblleave`
--
ALTER TABLE `tblleave`
  ADD PRIMARY KEY (`leaveID`),
  ADD UNIQUE KEY `leaveType` (`leaveType`);

--
-- Indexes for table `tblpagibig`
--
ALTER TABLE `tblpagibig`
  ADD PRIMARY KEY (`pagibigID`);

--
-- Indexes for table `tblphilhealth`
--
ALTER TABLE `tblphilhealth`
  ADD PRIMARY KEY (`philhealthID`);

--
-- Indexes for table `tblposition`
--
ALTER TABLE `tblposition`
  ADD PRIMARY KEY (`positionID`),
  ADD UNIQUE KEY `positionName` (`positionName`,`departmentID`);

--
-- Indexes for table `tblrates`
--
ALTER TABLE `tblrates`
  ADD PRIMARY KEY (`rateID`);

--
-- Indexes for table `tblsss`
--
ALTER TABLE `tblsss`
  ADD PRIMARY KEY (`sssID`);

--
-- Indexes for table `tbltaxdaily`
--
ALTER TABLE `tbltaxdaily`
  ADD PRIMARY KEY (`taxID`);

--
-- Indexes for table `tbltaxmonthly`
--
ALTER TABLE `tbltaxmonthly`
  ADD PRIMARY KEY (`taxID`);

--
-- Indexes for table `tblvoluntary`
--
ALTER TABLE `tblvoluntary`
  ADD PRIMARY KEY (`voluntaryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  MODIFY `departmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblemployee`
--
ALTER TABLE `tblemployee`
  MODIFY `employeeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblholiday`
--
ALTER TABLE `tblholiday`
  MODIFY `holidayID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblincentives`
--
ALTER TABLE `tblincentives`
  MODIFY `incentiveID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblleave`
--
ALTER TABLE `tblleave`
  MODIFY `leaveID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblpagibig`
--
ALTER TABLE `tblpagibig`
  MODIFY `pagibigID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblphilhealth`
--
ALTER TABLE `tblphilhealth`
  MODIFY `philhealthID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblposition`
--
ALTER TABLE `tblposition`
  MODIFY `positionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblrates`
--
ALTER TABLE `tblrates`
  MODIFY `rateID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblsss`
--
ALTER TABLE `tblsss`
  MODIFY `sssID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbltaxdaily`
--
ALTER TABLE `tbltaxdaily`
  MODIFY `taxID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbltaxmonthly`
--
ALTER TABLE `tbltaxmonthly`
  MODIFY `taxID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblvoluntary`
--
ALTER TABLE `tblvoluntary`
  MODIFY `voluntaryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
